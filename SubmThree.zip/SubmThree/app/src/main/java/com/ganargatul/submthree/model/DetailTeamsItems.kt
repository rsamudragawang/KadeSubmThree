package com.ganargatul.submthree.model

import com.google.gson.annotations.SerializedName

data class DetailTeamsItems (
    @SerializedName("strTeamBadge")
    val strTeamBadge:String?
)